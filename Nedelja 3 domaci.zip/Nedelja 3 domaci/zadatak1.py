def zavrsava_se_sa_slovom(recenica,slovo):
    recenice = recenica.split(".")
    #Inicijalizacija prazne liste za rezultat
    rezultat = []

    #Iteriranje kroz svaku recenicu
    for s in recenice:
        #Razdvajanje reci u recenici
        reci = s.split()
        #Filtriranje  reci koje se zavrsavaju zadatim slovom
        reci_se_zavrsavaju_slovom  = [rec for rec in reci if rec.endswith(slovo)]

        #Dodavanje torki u rezultatu (sam ako ima reci koje se zavrsavaju zadatim slovima)
        if reci_se_zavrsavaju_slovom:
            rezultat.append((reci_se_zavrsavaju_slovom,s.strip(),len(reci_se_zavrsavaju_slovom)))

    return rezultat

recenica =  "Štampaj reči koje se završavaju sa odredjenim slovom"
slovo = "m"
print(zavrsava_se_sa_slovom(recenica,slovo))