class Knjiga:
    def __init__(self, naslov, autor, godina, broj_kopija_inventara):
        self.__naslov = naslov
        self.__autor = autor
        self.__godina = godina
        self.__broj_kopija_inventara = broj_kopija_inventara

    # Geteri i seteri
    def get_naslov(self):
        return self.__naslov

    def set_naslov(self, naslov):
        self.__naslov = naslov

    def get_autor(self):
        return self.__autor

    def set_autor(self, autor):
        self.__autor = autor

    def get_godina(self):
        return self.__godina

    def set_godina(self, godina):
        self.__godina = godina

    def get_broj_kopija(self):
        return self.__broj_kopija_inventara

    def set_broj_kopija(self, broj_kopija_inventara):
        self.__broj_kopija_inventara = broj_kopija_inventara


class Biblioteka:
    def __init__(self):
        self.knjige = []

    def dodaj_knjigu(self, knjiga):
        self.knjige.append(knjiga)
        print("Knjiga '{}' je dodata u inventar.".format(knjiga.get_naslov()))

    def brisanje_knjige(self, naslov):
        for knjiga in self.knjige:
            if knjiga.get_naslov() == naslov:
                self.knjige.remove(knjiga)
                print("Knjiga '{}' je uklonjena iz inventara.".format(naslov))
                return
        print("Knjiga sa naslovom '{}' nije pronađena u inventaru.".format(naslov))

    def pretrazivanje_knjiga(self, query):
        nadji_knjigu = []
        for knjiga in self.knjige:
            if query.lower() in knjiga.get_naslov().lower() or query.lower() in knjiga.get_autor().lower():
                nadji_knjigu.append(knjiga)
        return nadji_knjigu

    def prikazi_dostupne_knjige(self):
        if not self.knjige:
            print("Trenutno nema dostupnih knjiga u inventaru.")
            return
        print("Dostupne knjige: ")
        for knjiga in self.knjige:
            print("Naslov: {}, Autor: {}, Godina izdanja: {}".format(knjiga.get_naslov(), knjiga.get_autor(),
                                                                     knjiga.get_godina()))


def main():
    biblioteka = Biblioteka()

    while True:
        print("\nOpcije: ")
        print("1. Dodaj knjigu")
        print("2. Pregled dostupnih knjiga")
        print("3. Pretraga knjiga")
        print("4. Uredi knjigu ")
        print("5. Ukloni knjigu ")
        print("6. Izlaz")

        izbor = input("Izaberite opciju: ")

        if izbor == '1':
            naslov = input("Unesite naslov knjige: ")
            autor = input("Unesite autora knjige: ")
            godina = input("Unesite godinu izdanja knjige: ")
            broj_kopija_inventara = int(input("Unesite broj kopija knjige u inventaru: "))
            knjiga = Knjiga(naslov, autor, godina, broj_kopija_inventara)
            biblioteka.dodaj_knjigu(knjiga)

        elif izbor == '2':
            biblioteka.prikazi_dostupne_knjige()

        elif izbor == "3":
            query = input("Unesite naslov ili autora knjige za pretragu: ")
            nadji_knjigu = biblioteka.pretrazivanje_knjiga(query)
            if nadji_knjigu:
                print("Pronađene knjige:")
                for knjiga in nadji_knjigu:
                    print("Naslov: {}, Autor: {}, Godina izdanja: {}".format(knjiga.get_naslov(), knjiga.get_autor(),
                                                                             knjiga.get_godina()))
            else:
                print("Nema pronađenih knjiga za uneti kriterijum pretrage.")

        elif izbor == '4':
            naslov = input("Unesite naslov knjige koju želite da uredite: ")
            for knjiga in biblioteka.knjige:
                if knjiga.get_naslov() == naslov:
                    print("Izaberite koji atribut želite da izmenite:")
                    print("1. Naslov")
                    print("2. Autor")
                    print("3. Godina izdanja")
                    print("4. Broj kopija")
                    izbor_atributa = input("Izaberite opciju: ")
                    if izbor_atributa == '1':
                        novi_naslov = input("Unesite novi naslov: ")
                        knjiga.set_naslov(novi_naslov)
                        print("Naslov knjige '{}' je uspešno izmenjen.".format(naslov))
                    elif izbor_atributa == '2':
                        novi_autor = input("Unesite novog autora: ")
                        knjiga.set_autor(novi_autor)
                        print("Autor knjige '{}' je uspešno izmenjen.".format(naslov))
                    elif izbor_atributa == '3':
                        nova_godina = input("Unesite novu godinu izdanja: ")
                        knjiga.set_godina(nova_godina)
                        print("Godina izdanja knjige '{}' je uspešno izmenjena.".format(naslov))
                    elif izbor_atributa == '4':
                        novi_broj_kopija_inventara = int(input("Unesite novi broj kopija: "))
                        knjiga.set_broj_kopija(novi_broj_kopija_inventara)
                        print("Broj kopija knjige '{}' je uspešno izmenjen.".format(naslov))
                    else:
                        print("Neispravan izbor atributa.")
                    break
            else:
                print("Knjiga sa naslovom '{}' nije pronađena u inventaru.".format(naslov))

        elif izbor == '5':
            naslov = input("Unesite naslov knjige koju želite da uklonite: ")
            biblioteka.brisanje_knjige(naslov)

        elif izbor == '6':
            print("Hvala što koristite biblioteku. Doviđenja!")
            break

        else:
            print("Neispravan izbor. Molimo izaberite ponovo.")


if __name__ == "__main__":
    main()

