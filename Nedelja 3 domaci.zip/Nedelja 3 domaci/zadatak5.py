niz= [{'naziv':'Español para principiantes', 'br_pozitivni':1000,'br_negativni':10},
{'naziv':'Philophize This!', 'br_pozitivni':500,'br_negativni': 30}, {'naziv':'Science VS. ',
'br_pozitivni':600,'br_negativni': 45}]

odnos =[]
def najogori_odnos_poz_neg_komentara(niz):
      najgori_podcast = None
      najgori_odnos = float('inf')
      for i in niz:
            odnos = niz['br_negativni'] / ['br_pozitivni']
            if odnos  < najgori_odnos:
                  najgori_odnos = odnos
                  najgori_podcast = niz['naziv']
      return

najgori_podcast = najogori_odnos_poz_neg_komentara(niz)
print("Najgori  podcast je:  ",najgori_podcast)    
            