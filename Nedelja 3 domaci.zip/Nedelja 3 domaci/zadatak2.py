def nadji_proizvod_najveceg_podniza(lista):
    maksimalni_proizvod = 1
    maksimalni_podniz = []

    for i in range(len(lista)):
        for j in range(i+1,len(lista)+1):
            podniz = lista[i:j]
            proizvod = 1
            for num in podniz:
                proizvod *= num
            if  proizvod > maksimalni_podniz:
                maksimalni_proizvod = proizvod
                maksimalni_podniz = podniz
    return maksimalni_podniz,maksimalni_proizvod


lista = [1,2,2,2,2,2,4,4]
maksimalni_podniz,maksimalni_proizvod = nadji_proizvod_najveceg_podniza(lista)
print("Najveća ponavljajuća sekvencija:  ",maksimalni_podniz)
print("Proizvod je sekvence :" ,maksimalni_podniz)

