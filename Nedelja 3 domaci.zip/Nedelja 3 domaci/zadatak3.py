def najduzi_testerast_podniz(niz):
    trenutna_duzina = 1
    maks_duzina = 1
    maks_podniz_pocetak = 0


    for i in range(len(niz) -2):
        if (niz[i] < niz[i+1] > niz[i+2]) or (niz[i] > niz[i+1] < niz[i+2]):
            trenutna_duzina +=1
            if trenutna_duzina > maks_duzina:
                maks_duzina = trenutna_duzina
                maks_podniz_pocetak = trenutna_duzina
                maks_podniz_pocetak = i - trenutna_duzina + 2
            else:
                trenutna_duzina = 1
        
    return niz[maks_podniz_pocetak :maks_podniz_pocetak + maks_duzina]

niz = [1, 2, 3, 2, 1, 4, 3, 2, 5, 4, 3, 2, 1]
print("Najduži testerasti podniz:", najduzi_testerast_podniz(niz))