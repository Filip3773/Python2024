class Player:
    def __init__(self, x, y, width, height, health):
        self._x = x
        self._y = y
        self._width = width
        self._height = height 
        self._health = health
       
    # Getter 
    def get_x(self):
        return self._x
    
    def get_y(self):
        return self._y
    
    def get_width(self):
        return self._width  
    
    def get_height(self):
        return self._height 
    
    def get_health(self):
        return self._health 
    
    # Setter 
    def set_x(self, x):
        self._x = x

    def set_y(self, y):
        self._y = y

    def set_width(self, width):
        self._width = width 
   
    def set_height(self, height):
        self._height = height
    
    def set_health(self, health):
        if 0 <= health <= 100:
            self._health = health
        else:
            print("Health parameter must be between 0 and 100")

class Enemy(Player):
    def __init__(self, x, y, width, height, damage):
        super().__init__(x, y, width, height, damage)
        self._damage = damage

    def get_damage(self):
        return self._damage
    
    def set_damage(self, damage):
        self._damage = damage

def check_collision(player, enemy):
    if (player.get_x() < enemy.get_x() + enemy.get_width() and
        player.get_x() + player.get_width() > enemy.get_x() and
        player.get_y() < enemy.get_y() + enemy.get_height() and
        player.get_y() + player.get_height() > enemy.get_y()):
        print("Sudaraju se")
        return True
    else:
        print("Ne sudaraju se")
        return False

def decrease_health(player, enemy):
    if check_collision(player, enemy):
        player.set_health(player.get_health() - enemy.get_damage())
        print("Player's health:", player.get_health())

player1 = Player(2, 3, 6, 4, 100)
enemy1 = Enemy(2, 3, 6, 4, 20)

decrease_health(player1, enemy1)
