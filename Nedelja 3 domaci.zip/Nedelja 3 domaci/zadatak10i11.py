class Color:
    def __init__(self,red,green,blue):
        self.__red = red
        self.__green = green
        self.__blue = blue

    #Getteri
    def get_red(self):
        return self.__red

    def get_green(self):
        return self.__green 

    def get_blue(self):
        return self.__blue 
    
    #Setteri

    def set_red(self,red):
        if 0 < red < 256: 
          self.__red = red
        else:
           print("Vrednost mora da bude izmedju 0 i 256")  
    
    def set_green(self,green):
        if 0 < green < 256: 
          self.__green = green
        else:
           print("Vrednost mora da bude izmedju 0 i 256")
    
    def set_blue(self,blue):
        if 0 < blue < 256:
         self.__blue = blue
        else:
           print("Vrednost mora da bude izmedju 0 i 256")
    
    def add_red(self, change):
        new_red = self.red + change
        if new_red < 0:
            self.red = 0
        elif new_red > 255:
            self.red = 255
        else:
            self.red = new_red
    def add_green(self,change):
        new_green = self.green + change   
        if new_green < 0:
           self.green = 0
        elif new_green > 255:
             self.green = 255
        else:
            self.green = new_green

    def add_blue(self,change):
        new_blue = self.blue + change
        if new_blue < 0:
            self.blue = 0
        elif new_blue > 255:
            self.blue = 255
        else:
            self.blue = new_blue

    
    def __lt__(self, other):
        if self.red < other.red and self.green < other.green and self.blue < other.blue:
            return True
        else:
            return False

    def __eq__(self, other):
        if self.red == other.red and self.green == other.green and self.blue == other.blue:
            return True
        else:
            return False

    def __str__(self):
        return f'"red": {self.__red}, "green": {self.__green}, "blue": {self.__blue}'
    
color = Color(100, 50, 25)
print(str(color))

class AlphaColor(Color):
    def __init__(self, red, green, blue,alpha):
        super().__init__(red, green, blue)
        self.__alpha  = alpha

    #Getter
    def get_alpha(self):
        return self.__alpha
    
    def set_alpha(self,alpha):
        if 0 < float(alpha) < 1:
            self.__alpha = alpha
        else:
            print("Vrednosti moraju da budu izmedju 0 i 1")  
            
    def update_color_by_alpha(self,alpha):
        self.set_red(self.get_red() - self.get_red() *alpha)
        self.set_green(self.get_green() - self.get_green() *alpha)
        self.set_blue(self.get_blue() -self.get_blue() *alpha)

    def __str__(self):
        return f'{super().__str__()},"alpha": {self.get_alpha}'
    

alfa_boja = AlphaColor(100,123,200,0.4)
alfa_boja1 = AlphaColor(50,100,150,0.8)
print(alfa_boja)
print(alfa_boja1)
alfa_boja.update_color_by_alpha(0.2)
alfa_boja1.update_color_by_alpha(0.4)
print(alfa_boja)
print(alfa_boja1)
