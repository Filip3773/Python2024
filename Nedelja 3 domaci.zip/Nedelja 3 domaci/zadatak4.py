a = input("Unesi neki string: ")
b = list(a)
counter = 0

def koliko_se_poklapa_susedni(b):
    global counter
    for i in range(len(b)-1):
        if b[i] == b[i+1]:
            counter += 1

koliko_se_poklapa_susedni(b)
print(counter)
