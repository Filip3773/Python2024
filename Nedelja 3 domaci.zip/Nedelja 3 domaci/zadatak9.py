import random

class Turnir:
    def __init__(self, naziv_turnira, lista_igraca, broj_rundi):
        self.__naziv_turnira = naziv_turnira
        self.__lista_igraca = lista_igraca
        self.__broj_rundi = broj_rundi

    def get_naziv_turnira(self):
        return self.__naziv_turnira
    
    def get_broj_rundi(self):
        return self.__broj_rundi
    
    def get_lista_igraca(self):
        return self.__lista_igraca
    
    def set_naziv_turnira(self, naziv_turnira):
        self.__naziv_turnira = naziv_turnira
    
    def set_lista_igraca(self, lista_igraca):
        self.__lista_igraca = lista_igraca

    def set_broj_rundi(self, broj_rundi):
        if 0 <= broj_rundi <= 10:
            self.__broj_rundi = broj_rundi
        else:
            print("Broj rundi mora biti između 0 i 10.")

    def dodaj_igraca(self, ime_igraca):
        novi_igrac = (ime_igraca, 0)
        self.__lista_igraca.append(novi_igrac)

    def obrisi_igraca(self, ime_igraca):
        for igrac in self.__lista_igraca:
            if igrac[0] == ime_igraca:
                self.__lista_igraca.remove(igrac)
   
    def prikazi_najboljeg_igraca(self):
        najbolji_igrac = max(self.__lista_igraca, key=lambda x: x[1])
        return najbolji_igrac[0]

    def pokreni_rundu(self):
        if len(self.__lista_igraca) < 2:
            print("Potrebno je najmanje dva igrača za pokretanje runde.")
            return

        igrac1, igrac2 = random.sample(self.__lista_igraca, 2)
        bodovi_igrac1 = igrac1[1]
        bodovi_igrac2 = igrac2[1]
        vjerovatnoca_pobjede_igrac1 = 0.6

        if random.random() < vjerovatnoca_pobjede_igrac1:
            pobednik = igrac1
            gubitnik = igrac2
        else:
            pobednik = igrac2
            gubitnik = igrac1
        
        print(f"Runda: {pobednik[0]} pobjeđuje {gubitnik[0]}!")
        pobednik_index = self.__lista_igraca.index(pobednik)
        self.__lista_igraca[pobednik_index] = (pobednik[0], pobednik[1] + 1)

        self.__broj_rundi += 1
lista_igraca = [
    ("Igrač 1", 10),
    ("Igrač 2", 8),
    ("Igrač 3", 12),
]

turnir = Turnir("Turnir", lista_igraca, 0)

turnir.pokreni_rundu()  

