class Company:
    def __init__(self,name,area,employees,balance,max_num_of_employees):
        self.__name = name
        self.__area = area
        self.__employees = employees 
        self.__balance = balance
        self.__max_num_of_employees = max_num_of_employees
        self.employees = []

    #Geteri
    def get_name(self):
        return self.__name  
    def get_area(self):
        return self.__area
    def get_balance(self):
        return self.__balance
    def get_max_num_of_employees(self):
        return self.__max_num_of_employees
    
    #Seteri 
    def set_name(self,name):
        self.__name = name
    
    def set_area(self,area):
        self.__area = area
    
    def set_balance(self,balance):
        if  0 < balance :
          self.__balance = balance
        else:
           print("Vrednost mora da bude vece 0 ")

    

    def set_max_num_of_employees(self,max_num_of_employees):
        if  0 < max_num_of_employees:
          self.__max_num_of_employees = max_num_of_employees   
        else:
           print("Vrednost mora da budu vece od 0 ")
    def add_employee(self, employee):
        if len(self.employees) < self.max_num_of_employees:
            self.employees.append(employee)
            print("Employee je dodat")
        else:
            print("Maximalan broj  zapososlenih je postignut nemoze da se doda jos.")
    def remove_employee(self, employee_name, employee_surname):
        for i, (name, surname) in enumerate(self.employees):
            if name == employee_name and surname == employee_surname:
                del self.employees[i]
                print(f"{employee_name} {employee_surname} je uklonjen(a) iz kompanije.")
                return

