class Televizor:
    def __init__(self,broj_trenutnog_kanala,naziv_trenutnog_kanala,kanali,jačina_tona):
        self.__broj_trenutnog_kanala = broj_trenutnog_kanala
        self.__naziv_trenutnog_kanala = naziv_trenutnog_kanala
        self.__kanali = kanali
        self.__jačina_tona = jačina_tona
        
    
    #Getteri i setteri
    def get_broj_trenutnog_kanala(self):
        return self.__broj_trenutnog_kanala
    
    def set_broj_trenutnog_kanala(self,broj):
        self.__broj_trenutnog_kanala = broj
    
    def set_naziv_trenutnog_kanala(self,naziv):
        self.__naziv_trenutnog_kanala = naziv

    def get_naziv_trenutnog_kanala(self):
        return self.__naziv_trenutnog_kanala
    
    def get_kanali(self):
        return self.__kanali
    
    def set_kanali(self,kanali):
        self.__kanali = kanali
    
    def get_jačina_tona(self):
        return self._jačina_tona
    
    def set_jačina_tona(self, jacina):
         self.__jačina_tona = jacina
#Metode
    #Dodavanje kanala
    def dodaj_kanal(self,naziv_kanala):
        self.__kanali.append(naziv_kanala)

    #Brisanje kanala
    def obriši_kanal(self,naziv_kanala):
        if naziv_kanala in self.__kanali:
            self.__kanali.remove(naziv_kanala)
            #Resetovanje trenutnog kanala ako je obrisan
            if self.__naziv_trenutnog_kanala == naziv_kanala:
                  self.__broj_trenutnog_kanala = 0
                  self.__naziv_trenutnog_kanala = ""
    #Pojačavanje tona
    def pojačani_ton(self):
        if self.__jačina_tona <10:
            self.__jačina_tona += 1
    #Metoda za dobijanje broja kanala na osnovu broja kanala
    def ime_kanala(self,broj_kanala):
        if 1 <= broj_kanala <= len(self.__kanali):
            return self.__kanali[broj_kanala - 1]
        else:
            return "Kanal ne postoji"        
