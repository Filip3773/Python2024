import requests 
from bs4 import BeautifulSoup
import csv
from datetime import datetime

def scrape_realitica(city_or_category):
    base_url = f'https://www.realitica.com/?cur_page=1&for={city_or_category}'
    all_properties = []

    while base_url:
        response = requests.get(base_url)
        soup = BeautifulSoup(response.text, 'html.parser')

        listinzi = soup.find_all('div', class_='listing')
        for listing in listinzi:
            podaci_o__nekretnini = {}

            podaci_o__nekretnini['vrsta'] = listing.find('span', class_='catI').text.strip()
            podaci_o__nekretnini['područje'] = listing.find('span', class_='catII').text.strip()
            podaci_o__nekretnini['lokacija'] = listing.find('span', class_='locationI').text.strip()
            podaci_o__nekretnini['broj spavaćih soba'] = int(listing.find('span', class_='bedrooms').text.strip())
            podaci_o__nekretnini['broj kupila'] = int(listing.find('span', class_='bathrooms').text.strip())
            podaci_o__nekretnini['cijena'] = float(listing.find('span', class_='price').text.strip().replace(' €', '').replace('.', '').replace(',', '.'))
            podaci_o__nekretnini['stambena površina'] = int(listing.find('span', class_='area').text.strip().replace(' m2', ''))
            podaci_o__nekretnini['zemljište'] = int(listing.find('span', class_='land-area').text.strip().replace(' m2', ''))
            podaci_o__nekretnini['parking mjesta'] = int(listing.find('span', class_='garages').text.strip()) if listing.find('span', class_='garages') else 0
            podaci_o__nekretnini['od mora'] = int(listing.find('span', class_='fromsea').text.strip().replace(' m', '')) if listing.find('span', class_='fromsea') else 0
            podaci_o__nekretnini['novogradnja'] = True if listing.find('span', class_='novogradnja') else False
            podaci_o__nekretnini['klima'] = True if listing.find('span', class_='klima') else False
            podaci_o__nekretnini['naslov'] = listing.find('h2').text.strip()
            podaci_o__nekretnini['opis'] = listing.find('div', class_='description').text.strip()
            podaci_o__nekretnini['web stranica'] = listing.find('a', class_='web').get('href') if listing.find('a', class_='web') else ''
            podaci_o__nekretnini['oglasio'] = listing.find('span', class_='agent').text.strip()
            podaci_o__nekretnini['mobilni'] = listing.find('span', class_='phone').text.strip()
            podaci_o__nekretnini['broj/id oglasa'] = int(listing.find('span', class_='pid').text.strip())
            podaci_o__nekretnini['zadnja promjena'] = datetime.strptime(listing.find('span', class_='change_date').text.strip(), '%d.%m.%Y. %H:%M')
            podaci_o__nekretnini['slike'] = [img['src'] for img in listing.find_all('img', class_='img-fluid') if 'noimage' not in img['src']]
            podaci_o__nekretnini['link do nekretnine'] = listing.find('a', class_='ad-link').get('href')

            all_properties.append(podaci_o__nekretnini)

        nova_stranica = soup.find('a', text='Next -> ')
        base_url = 'https://www.realitica.com/' + nova_stranica['href'] if nova_stranica else None

    return all_properties

def save_to_csv(properties, filename):
    keys = properties[0].keys()
    with open(filename, 'w', newline='', encoding='utf-8') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(properties)

def main():
    city_or_category = input("Unesite grad ili kategoriju nekretnina: ")
    properties = scrape_realitica(city_or_category)
    if properties:
        save_to_csv(properties, f"{city_or_category}_nekretnine.csv")
        print(f"Podaci su spremljeni u datoteku: {city_or_category}_nekretnine.csv")
    else:
        print("Nije pronađena nijedna nekretnina.")

if __name__ == "__main__":
    main()
