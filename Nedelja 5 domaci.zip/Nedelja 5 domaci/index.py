import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

df = pd.read_csv('imdb_top_2000_movies.csv')

kolona_ime = 'IMDB Rating'

print(df.head())
print(df.info())
numeric_df = df.select_dtypes(include=['number'])

# Normalizacija
scaler = MinMaxScaler()
df[kolona_ime] = scaler.fit_transform(df[[kolona_ime]])

srednja_vrijednost = df[kolona_ime].mean()
max_vrijednost = df[kolona_ime].max()
min_vrijednost = df[kolona_ime].min()
procentualna_razlika = ((max_vrijednost - srednja_vrijednost) / max_vrijednost) * 100

korelacija = numeric_df.corr()
max_pozitivna_korelacija = korelacija[kolona_ime].nlargest(2).index.tolist()
max_negativna_korelacija = korelacija[kolona_ime].nsmallest(2).index.tolist()

standarna_devijacija = df[kolona_ime].std()

print("Statistika za kolonu '{}'".format(kolona_ime))
print("Prosječna vrednost:", srednja_vrijednost)
print("Najveća vrednost:", max_vrijednost)
print("Najmanja vrednost:", min_vrijednost)
print("Procentualna razlika između prosečne i najveće vrednosti: {:.2f}%".format(procentualna_razlika))
print("Dvije kolone s najvećom pozitivnom korelacijom:", max_pozitivna_korelacija)
print("Dvije kolone s najvećom negativnom korelacijom:", max_negativna_korelacija)
print("Standardna devijacija za kolonu '{}':".format(kolona_ime))
print(standarna_devijacija)

plt.hist(df[kolona_ime], bins=30)
plt.title("Raspodela vrednosti u koloni {}".format(kolona_ime))
plt.xlabel('Vrednost')
plt.ylabel('Broj instanci')
plt.show()
#iz nekog razlog moram da stavim graf posle ovih print statementa jer u obrnutom slučaju neće da mi ih prikaže , ne znam zasto