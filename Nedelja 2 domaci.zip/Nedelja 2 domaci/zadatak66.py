lista_celih_brojeva = [112.332,223,442,334,212,11,22,]
trocifreni = []
dvocifreni = []
def broj_cifara(lista):
    for i in lista:
        if i%100 >0:
            trocifreni.append(i)
        else:
            dvocifreni.append(i)

broj_cifara(lista_celih_brojeva)
if len(trocifreni) > len(dvocifreni):
    print("Vise trocifrenih")
else:
    print("Vise dvocifrenih")

