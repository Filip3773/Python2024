n = int(input("Unesi broj: "))
lista = []
parni = []
neparni = []

def proizvod_liste(neparni):
    result = 1
    for i in neparni:
        result *= i
    return result

a = n // 1000
b = (n % 1000) // 100
c = ((n % 1000) % 100) // 10
d = (((n % 1000) % 100) % 10)

lista.extend([a, b, c, d])

for i in lista:
    if i % 2 == 0:
        parni.append(i)
    else:
        neparni.append(i)

print("Suma parnih brojeva:", sum(parni))
print("Proizvod neparnih brojeva:", proizvod_liste(neparni))
