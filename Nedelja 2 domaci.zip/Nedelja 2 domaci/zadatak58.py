a = input("Unesi neki string :")
b = list(a)
bez_brojeva = []
def izbcivanje_cifara(a):
    for i in a:
        if i.isalpha() or  not i.isdigit():
            bez_brojeva.append(i)
        
izbcivanje_cifara(b)
bez_brojeva = ''.join([str(elem)for elem in bez_brojeva])
print(bez_brojeva)