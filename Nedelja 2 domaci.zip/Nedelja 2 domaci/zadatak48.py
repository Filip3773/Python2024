osnova = int(input("Unesi osnovu broja : "))
stepen_broja = int(input("Unesi stepen datog broja: "))

def stepenovanje(osnova,stepen_broja):
    result = 1
    for i in range(stepen_broja):
        result *= osnova
    return result

rezultat = stepenovanje(osnova,stepen_broja)
print(f"{osnova} na {stepen_broja} je jednako {rezultat}.")