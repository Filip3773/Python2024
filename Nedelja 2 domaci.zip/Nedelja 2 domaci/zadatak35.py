def extract_digits_and_concatenate(text):
    digits = ""
    for char in text:
        if char.isdigit():
            digits += char
    if digits:
        return int(digits)
    else:
        return None

text = "Hi Mr. Rober53. How are you today? Today is 08.10.2019"
result = extract_digits_and_concatenate(text)
if result is not None:
    print(result)
else:
    print("No digits found in the text.")
