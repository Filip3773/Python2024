r = input("Poluprecni pikado table: ")
x1,y1 = input("Unesi x,y kordinate centra").split(',')
x2,y2, = input("Unesite x,y kordinate strelice").split(',')

x1 = int(x1)
x2 = int(x2)
y1= int(y1)
y2 = int(y2)

if ((x2 -x1)**2 + (y2+y1)**2) == r**2:
    print("Nalazi se na pikado tabli")
else:
    print("Ne nalazi se na pikado tabli")