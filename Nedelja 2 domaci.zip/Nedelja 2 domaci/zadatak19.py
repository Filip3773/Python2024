def iznos_skolarine(iznos, ocena, nagrada):
    if ocena >= 4.5:
        popust_uspeh = 0.4
    elif ocena >= 4.0:
        popust_uspeh = 0.2
    elif ocena >= 3.5:
        popust_uspeh = 0.1
    else:
        popust_uspeh = 0
    
    if nagrada == 1:
        popust_nagrada = 0.3
    else:
        popust_nagrada = 0
    
    if popust_uspeh > popust_nagrada:
        popust = popust_uspeh
    else:
        popust = popust_nagrada
    
    iznos_popust = iznos * (1 - popust)
    
    return round(iznos_popust)

# Testiranje funkcije
iznos = float(input())
ocena = float(input())
nagrada = int(input())

print(iznos_skolarine(iznos, ocena, nagrada))
