a =input("Unesi broj: ")
a=list(a)
def da_li_je_binaran(a):
 for char in a:
    if char != "0" and char !="1":
        return False
 return True

if da_li_je_binaran(a):
   print("Binaran")
else:
   print("Nije binaran")
   