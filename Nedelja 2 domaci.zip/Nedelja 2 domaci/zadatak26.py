a = input("Unesi broj:")
if a[0:2] == "0b":
    print("Binarni")
elif a[0:2] == "0o":
    print("Oktalni")
elif  a[0:2] == "0x":
    print("Heksadecimalni")
else:
    print("dekadni")