a = input("Unesi neki tekst  ")
b = list(a)
samoglasnici = []
def izdvoj_samoglasnike(a):
    for i in b:
        if i == "a" or i == "e" or i == "i" or i == "o" or i =="u":
           samoglasnici.append(i)
        

izdvoj_samoglasnike(a)
c = str(samoglasnici)
print(c)