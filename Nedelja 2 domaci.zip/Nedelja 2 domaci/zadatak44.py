broj_poseta_po_utakmici=[100,123,124,153,126,1867,344,45,564,234]
def najveci_broj_poseta(a):
     print(max(a))


najveci_broj_poseta(broj_poseta_po_utakmici)