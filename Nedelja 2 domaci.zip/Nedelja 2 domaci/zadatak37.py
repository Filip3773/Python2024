def provjeri_plus(niz):
    poeni = 0
    for znak in niz:
        if znak == '1':
            poeni += 1
        elif znak == '*':
            poeni -= 1
    return poeni > 0


n = "101*01*"
if provjeri_plus(n):
    print("Igrač je u plusu!")
else:
    print("Igrač nije u plusu.")
