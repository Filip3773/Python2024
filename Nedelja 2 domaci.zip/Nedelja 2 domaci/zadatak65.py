d = int(input("Unesi duzinu terase u metrima: "))
n = int(input("Unesi broj stubica : "))
s = int(input("Unesi realan broj koji predstavlja sirinu stubica u cm"))

r=((d*100)-(n*s))/(n+1)
print(r)