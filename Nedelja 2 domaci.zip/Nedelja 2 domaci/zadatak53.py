

def broj_golova(zbir):
    broj_golova = 0
    for i in range(1, zbir):
        if zbir - i >= i:
            broj_golova += 1
    return broj_golova

petrov_zbir = int(input("Unesite Petrov zbir: "))
print("Broj golova na utakmici je:", broj_golova(petrov_zbir))
