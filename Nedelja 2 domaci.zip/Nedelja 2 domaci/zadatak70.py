lista = [1,2,3,4,5,6,7,8,9,10]
deljivi_sa_tri =  []
def pasos(lista):
    for i in lista:
        if i%3 == 0:
            deljivi_sa_tri.append(i)
pasos(lista)
kvadrati = []
def licna(c): 
    for i in c:
         b =  i**2    
         kvadrati.append(b)


licna(deljivi_sa_tri)
print(sum(kvadrati))        

