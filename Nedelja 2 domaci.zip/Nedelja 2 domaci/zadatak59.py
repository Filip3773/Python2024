s = input("Unesi string:  ")
enkriptovan_tekst = []
def enkripcija(s):
    for i in s:
        if int(i)%2 == 0:
            i = 0
            enkriptovan_tekst.append(i)
        else:
            i=1
            enkriptovan_tekst.append(i)

enkripcija(s)
enkriptovan_tekst = ''.join([str(elem)for elem in enkriptovan_tekst])
print(enkriptovan_tekst)