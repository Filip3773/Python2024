a = input("Unesi lozinku broj karakter ne treba da je veći od 100:  ")
b = list(a)
mala_slova = []
velika_slova = []
def da_li_je_jaka(a):
    if  len(a) > 8 :
        for i in a :
            if  i.islower():
                mala_slova.append(i)
            else:
                velika_slova.append(i)
        if len(mala_slova) > 0 and len(velika_slova) > 0:
            print("Šifra je jaka")
    else:
        print("Šifra je slaba")     

da_li_je_jaka(b)