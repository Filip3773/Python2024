def enkriptuj_string(s):
    enkriptovan_string = ""
    for karakter in s:
        if karakter.isdigit():  
            broj = int(karakter)
            if broj % 2 == 0:  
                enkriptovan_string += '0'
            else:  
                enkriptovan_string += '1'
    return enkriptovan_string
 
s = '15023'


rezultat = enkriptuj_string(s)

print("Enkriptovan string:", rezultat)