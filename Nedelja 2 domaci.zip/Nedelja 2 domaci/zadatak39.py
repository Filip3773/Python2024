def je_narcis_broj(broj):
    broj_str = str(broj)
    broj_cifara = len(broj_str)
    suma_stepenova = sum(int(cifra)**broj_cifara for cifra in broj_str)
    return suma_stepenova == broj
def proveri_narcis_broj():
    broj = int(input("Unesite broj: "))
    if je_narcis_broj(broj):
        print("Da")
    else:
        print("Ne")
proveri_narcis_broj()
