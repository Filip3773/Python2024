def prilagodi_plate(plate):
    prosecna_plata = sum(plate) / len(plate)
    prilagodjene_plate = []

    for plata in plate:
        if plata > prosecna_plata:
            prilagodjene_plate.append(plata * 0.9)  
        else:
            prilagodjene_plate.append(plata * 1.1)  
    
    return prilagodjene_plate

def main():
    plate = [3000, 2500, 4000, 2000, 3500]

    prilagodjene_plate = prilagodi_plate(plate)

    print("Originalne plate:", plate)
    print("Prosečna plata:", sum(plate) / len(plate))
    print("Plate nakon prilagođavanja:", prilagodjene_plate)

if __name__ == "__main__":
    main()
