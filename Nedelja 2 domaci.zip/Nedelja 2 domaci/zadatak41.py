def broj_manjih_elemenata(L, max_vrijednost):
    counter = 0
    for element in L:
        if element < max_vrijednost:
            counter += 1
    return counter


a1 = [1, 2, 3]
max1 = 3
print("Input:", a1, "max =", max1, "; Output:", broj_manjih_elemenata(a1, max1))

a2 = [-1, 0, 5]
max2 = -2
print("Input:", a2, "max =", max2, "; Output:", broj_manjih_elemenata(a2, max2))
