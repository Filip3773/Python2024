def enkriptuj_string(s):
    enkriptovani_string = ""
    for karakter in s:
        if karakter in "aeiou":
            enkriptovani_string += "1"  
        else:
            enkriptovani_string += "0"  
    return enkriptovani_string


s = input("Unesite string koji želite enkriptovati: ").lower()  
enkriptovani_string = enkriptuj_string(s)
print("Enkriptovani string:", enkriptovani_string)
