def provjeri_kvadrate(pravougaonik):
    a, b = pravougaonik  # Dimenzije pravougaonika
    # Pronalaženje najvećeg zajedničkog djelitelja
    while b:
        a, b = b, a % b
    # Provjera mogućnosti
    if pravougaonik[0] % a == 0 and pravougaonik[1] // a >= 2:
        return "Moguće je napraviti dva kvadrata."
    else:
        return "Nije moguće napraviti dva kvadrata."

# Unos dimenzija pravougaonika
a = int(input("Unesite dužinu prve stranice pravougaonika: "))
b = int(input("Unesite dužinu druge stranice pravougaonika: "))
pravougaonik = (a, b)

# Provjera mogućnosti
rezultat = provjeri_kvadrate(pravougaonik)
print(rezultat)
