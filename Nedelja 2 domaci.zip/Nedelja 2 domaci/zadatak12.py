dvocifreni = int(input("Uneti dvocifreni broj:"))

prva = dvocifreni/10
druga = dvocifreni % 10

if prva > druga :
    print(prva-druga)
elif prva < druga:
    print(prva + druga)
else:
    print(prva*druga)

    