a =int(input("Unesi prvi broj: "))
b =int(input("Unesi drugi broj: ")) 
c =int(input("Unesi treci broj: ")) 

lista = []
lista.append(a)
lista.append(b)
lista.append(c)

print(max(lista))
print(min(lista))
