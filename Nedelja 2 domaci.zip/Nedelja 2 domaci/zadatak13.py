import math
r1 =int(input("Unesi poluprecnik prvog stola: "))
r2 =int(input("Unesi poluprecnik drugog stola: "))

if r1>r1:
    print((r1**2)*math.pi)
elif r2>r1:
    print((r2**2)*math.pi)
else:
    print("Oba stola imaju isti poluprecnik")