lista = [3, 4, 5, 3, 3, 5, 4, 5, 5, 5]
trojke = []
cetvorke = []
petice = []

def brojanje_ocena(a):
    global trojke, cetvorke, petice
    for i in a:
        if i == 3:
            trojke.append(i)
        elif i == 4:
            cetvorke.append(i)
        elif i == 5:
            petice.append(i)

brojanje_ocena(lista)
trojkee = len(trojke)
cetvorkee = len(cetvorke)
peticee = len(petice)
print(trojkee)
print(cetvorkee)
print(peticee)