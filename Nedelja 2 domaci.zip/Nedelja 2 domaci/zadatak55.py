h =int(input("Unesi broj vodonika: "))
o = int(input("Unesi broj kiseonika: "))

voda = h//o
print(voda)