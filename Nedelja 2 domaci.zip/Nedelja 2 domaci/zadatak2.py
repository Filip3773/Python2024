p = int(input())
m = int(input())
 
if p > m :
    print("Petar je pobedio")
elif m > p:
    print("Milos je pobedio")    
else :
    print("Nereseno je.")   
      