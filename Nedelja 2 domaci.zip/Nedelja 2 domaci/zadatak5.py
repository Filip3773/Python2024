def proveri_trougao(a, b, c):
    if a + b > c and a + c > b and b + c > a:
        return "Moguce je napraviti trougao sa datim duzinama stranica."
    else:
        return "Nije moguce napraviti trougao sa datim duzinama stranica."

# Unos dužina stranica trougla
a = float(input("Unesite duzinu prve stranice: "))
b = float(input("Unesite duzinu druge stranice: "))
c = float(input("Unesite duzinu trece stranice: "))

# Provera da li se može napraviti trougao
rezultat = proveri_trougao(a, b, c)
print(rezultat)