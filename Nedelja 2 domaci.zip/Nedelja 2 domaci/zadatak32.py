def suma_i_broj_djeljivih(a, b, djelilac):
    suma = 0
    broj_elemenata = 0
    for i in range(a + 1, b):
        if i % djelilac == 0:
            suma += i
            broj_elemenata += 1
    return suma, broj_elemenata

# Primjer korištenja funkcije:
a = int(input("Unesite vrijednost a: "))
b = int(input("Unesite vrijednost b: "))
djelilac = int(input("Unesite djelioca: "))

suma, broj_elemenata = suma_i_broj_djeljivih(a, b, djelilac)
print("Suma djeljivih elemenata:", suma)
print("Broj djeljivih elemenata:", broj_elemenata)
