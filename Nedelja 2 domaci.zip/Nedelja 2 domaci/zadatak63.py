a = input("Unesi input:  ")
duzina_reci = []
def najduza_rec(a):
    reci = a.split()
     
    for rec in reci:
        c = len(rec)
        duzina_reci.append(c)
najduza_rec(a)
print(max(duzina_reci))

    