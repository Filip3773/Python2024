n = int(input())
if n%2 == 0:
  print("Portal se otvara")
else :
   print("Portal ostaje zatvoren")


 





