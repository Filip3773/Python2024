broj_ukupnih_seminarksih = int(input("Unesi broj ukupnih potrebnih seminarskih radova:"))
broj_ukupnih_predavanja = int(input("Unesi ukupan broj predavanja :"))
prisustvo = int(input("Unesi broj predavanja na kojima je student prisustvovao:"))
seminarski_radovi = int(input("Unesi broj seminarski radova koje je student  predao:"))


if broj_ukupnih_predavanja == seminarski_radovi and (3/4)*(broj_ukupnih_predavanja) <= prisustvo:
    print("Student može da polaže ispit!")
else: 
    print("Student ne može da polaže ispit!")    


    