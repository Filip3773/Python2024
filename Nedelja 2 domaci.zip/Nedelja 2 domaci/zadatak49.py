string = input("Uneti neki tekst:  ")
duzina = int(input("Uneti neku duzinu za tekst "))

lista = list(string)

if len(lista) > duzina:
    print(string[0:duzina] + "...")
else:
    print(string)


