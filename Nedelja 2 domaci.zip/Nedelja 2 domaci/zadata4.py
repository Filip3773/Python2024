sat = int(input())
if sat > 6 or sat == 13 or sat == 14 or sat == 15 or sat== 16 or sat == 17 or sat > 22 :
    print("Nije moguce izvodjenje radova sad.")
else:
    print("Moguce izvoditi radove sad.")    