def main():
    start = int(input())
    end = int(input())
    suma = 0

    for broj in range(start, end + 1):
        if broj % 2 == 0 and broj % 4 != 0:
            suma += broj ** 2

    print(suma)

if __name__ == "__main__":
    main()
