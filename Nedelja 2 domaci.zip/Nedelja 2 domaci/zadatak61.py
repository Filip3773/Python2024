a = input("Unesi rečenicu ovde :  ")
b = list(a)
velika_slova = []
def vrati_velika_slova(b):
    for i in b:
        if i.isupper():
           velika_slova.append(i)
        
vrati_velika_slova(b)
velika_slova = ''.join([str(elem)for elem in velika_slova])
print(velika_slova)