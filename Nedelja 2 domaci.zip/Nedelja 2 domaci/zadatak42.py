def originalna_zarada(cene):
    return sum(cene)
def nova_zarada(cene,popust):
    nove_cene = [cene *(1 - popust)  for i in cene]
    return sum(nove_cene)

def razlika_u_zaradi(originalna_zarada,nova_zarada):
    return originalna_zarada - nova_zarada

def main():
    cene_proizvoda = [10,20,30,40,50]

    popust = 0.1
    
    originalna_zarada1 = originalna_zarada(cene_proizvoda)
    popust = 0.1
    
    nova_zarada1 = nova_zarada(cene_proizvoda,popust)
    razlika_zarade = razlika_u_zaradi(originalna_zarada1,nova_zarada1)

    print("Originalna zarada: ",originalna_zarada1) 
    print( "Nova  zarada: ", nova_zarada1)
    print("Razlika u  zaradi: ", razlika_zarade)


if __name__ == "__main__":
    main()