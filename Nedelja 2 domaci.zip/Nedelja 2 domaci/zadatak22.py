x,y = input("Unesi kordinate tacke").split(",")
x = int(x)
y = int(y)
if x >0 and y >0:
    print("Prvi kvadrant")
elif x>0 and y<0:
    print("Četvrti kvadrant ")
elif x<0 and y>0:
    print("Drugi kvadrant")
else:
    print("Treci kvadrant.")