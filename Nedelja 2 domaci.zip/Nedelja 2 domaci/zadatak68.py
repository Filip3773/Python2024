x = int(input("Unesi koliko ces da uvecas zarade  "))
zarade = [600,450,700,300,678,900,1200]
def prosecna_zarada(a,x):
    c = sum(a)/len(a)
    for i in a:
        if i > c:
            i = i + x
            print(i)
prosecna_zarada(zarade,x)


         