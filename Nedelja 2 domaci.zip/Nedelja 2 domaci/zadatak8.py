prosek = float(input("Unesite prosek ucenika: "))
da_li_ima_jedinicu = input("Da li ucenik ima jedinicu(Da ili Ne)?")
if  4.5>= prosek and da_li_ima_jedinicu == "Ne":
    print("Odličan učenik")
elif 3.5 <= prosek < 4.5 and da_li_ima_jedinicu == "Ne":
    print("Vrlo dobar")
elif 2.5 <= prosek < 3.5 and da_li_ima_jedinicu == "Ne":
    print("Dobar")
elif 2 <= prosek < 2.5 and da_li_ima_jedinicu == "Ne":
    print("Dovoljan")
elif   da_li_ima_jedinicu == "Da":
    print("Učenik je nedovoljan")