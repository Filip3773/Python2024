def odredi_pobednika(takmicari):
    # Sortiranje takmičara po ukupnom broju poena, a zatim po poenima iz programiranja
    sortirani_takmicari = sorted(takmicari, key=lambda x: (x[1] + x[2], x[2]), reverse=True)
    
    # Pobednik je prvi takmičar u sortiranoj listi
    pobednik = sortirani_takmicari[0]
    
    return pobednik

# Unos poena takmičara (matematika, programiranje)
takmicari = []
n = int(input("Unesite broj takmičara: "))
for i in range(n):
    ime = input("Unesite ime takmičara: ")
    matematika = int(input("Unesite broj poena iz matematike: "))
    programiranje = int(input("Unesite broj poena iz programiranja: "))
    takmicari.append((ime, matematika, programiranje))

# Poziv funkcije za određivanje pobednika
pobednik = odredi_pobednika(takmicari)
print(f"Pobednik takmičenja je {pobednik[0]} sa ukupno {pobednik[1] + pobednik[2]} poena.")
  
