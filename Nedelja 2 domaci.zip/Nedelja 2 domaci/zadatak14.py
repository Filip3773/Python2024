a =int(input("Unesi cenu nekog proizvoda a:"))
b =int(input("Unesi cenu nekog proizvoda b:"))
c =int(input("Unesi cenu nekog proizvoda c:"))

zbir1 = a+b
zbir2 = a+c
zbir3 = b+c

lista =[]

lista.append(zbir1)
lista.append(zbir2)
lista.append(zbir3)

print("Najmanji zbir proizvoda  :",min(lista))