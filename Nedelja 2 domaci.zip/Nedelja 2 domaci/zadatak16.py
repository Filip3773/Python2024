x1, y1 = input("Unesi x,y kordinate prve tačke (x, y format): ").split(',')
x2, y2 = input("Unesi x,y kordinate druge tačke (x, y format): ").split(',')
x3, y3 = input("Uneti kordinate tacke: ").split(',')

x1 = int(x1)
x2 = int(x2)
y1 = int(y1)
y2 = int(y2)
x3 = int(x3)
y3 = int(y3)

if x1 < x3 > x2  and y1 > y3 > y2:
    print("Nalazi se u  pravouganiku")
else:
    print("Nije u pravouganiku")
