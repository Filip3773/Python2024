s = input("Unesi neki broj ")
s= list(s)
s.sort()
zbir = int(s[-1]) -int(s[0])
razlika = int(s[-1]) + int(s[0])
print(zbir)
print(razlika)

