a = input("Unesi string :")
b = list(a)
def broj_heksadecimalan(a):
    brojac = 0
    reci = a.split()

    for rec in reci:
        if rec.startswith("0x"):
           brojac += 1
    return brojac

izlaz =   broj_heksadecimalan(a)
print(izlaz)