tekst = input("Unesi tekst:")
def a(b):
    novi_tekst = b[1:-1]
    return novi_tekst

print(a(tekst))
