n = int(input("Unesi broj n:"))

def proizvod_liste(neparni):
    result = 1
    for i in neparni:
        result *= i
    return result
parni=[]
neparni =[]
for i in range(1,n):
    if i%2==0:
       parni.append(i)
    else:
        neparni.append(i)

print(sum(parni)) 
print(proizvod_liste(neparni))