def proizvod_cifara(s):
    proizvod = 1
    for karakter in s:
        if karakter.isdigit():
            proizvod *= int(karakter)
    return proizvod

s = "Zdvo123Sete456"
print(proizvod_cifara(s))  
