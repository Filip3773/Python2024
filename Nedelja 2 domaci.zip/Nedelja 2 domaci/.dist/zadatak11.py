def proveri_poziciju_mrava(sto, pozicija_mrava):
    x, y = pozicija_mrava
    x1, y1 = sto[0]
    x2, y2 = sto[1]

    if (x == x1 or x == x2) and (y >= y1 and y <= y2):
        return True
    if (y == y1 or y == y2) and (x >= x1 and x <= x2):
        return True
    return False

sto = ((0, 0), (10, 10))
pozicija_mrava = (5, 5)

if proveri_poziciju_mrava(sto, pozicija_mrava):
    print("Mrav se nalazi na ivici stola.")
else:
    print("Mrav nije na ivici stola.")
