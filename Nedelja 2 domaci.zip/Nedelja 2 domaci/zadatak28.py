a =input("Unesi tekst: ")
b = input("Unesi target: ")
a=list(a)
if a[:-2] ==b:
    print("Da")
else:
    print("Ne")    
    