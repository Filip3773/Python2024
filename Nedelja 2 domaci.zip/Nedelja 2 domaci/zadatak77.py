def proveri_sortiranje(lista):
    if len(lista) <= 1:
        return True
    
    for i in range(len(lista) - 1):
        if lista[i] > lista[i + 1]:
            return False
    return True

moja_lista = [1, 3, 5, 7, 9]
print(proveri_sortiranje(moja_lista))

neuredjena_lista = [9, 2, 5, 8, 1]
print(proveri_sortiranje(neuredjena_lista))
