def je_prestupna(godina):
    if (godina % 4 == 0 and godina % 100 != 0) or (godina % 400 == 0):
        return True
    else:
        return False


godina = int(input("Unesi godinu: "))
if je_prestupna(godina):
    print(f"{godina}. je prestupna godina.")
else:
    print(f"{godina}. nije prestupna godina.")
