a = input("Unesi string: ")
b = list(a)
pozicija = int(input("Unesi poziciju mesta: "))
def da_li_je_slobodno_mesto(a,pozicija):
     if a[pozicija-1]=="0" and a[pozicija+1] == "0":
          print("Mesta okolo su slobodna")
     elif a[pozicija-1]=="1" and a[pozicija+1] == "0":
          print("Levo mesto je zauzeto")
     elif a[pozicija-1]=="0" and a[pozicija+1] == "1":
          print("Desno mesto je zauzeto")
     else:
          print("Oba mesta su zauzeta")        
    
da_li_je_slobodno_mesto(a,pozicija)