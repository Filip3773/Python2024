def je_narcis(broj):
    broj_str = str(broj)
    broj_cifara = len(broj_str)
    
    suma_st = sum(int(cifra) ** broj_cifara for cifra in broj_str)
    
    return suma_st == broj

broj = int(input("Unesite broj: "))

if je_narcis(broj):
    print("Da")
else:
    print("Ne")