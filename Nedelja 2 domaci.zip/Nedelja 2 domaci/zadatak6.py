kordinata_x_pcele = int(input("Unesite kordinatu x pčele:"))
kordinata_y_pcele = int(input("Unesite kordinatu y pčele:"))

if kordinata_y_pcele == kordinata_x_pcele*2 + 5:
   print("Pčela se kreće po žici!")
else:
   print("Pčela se ne kreće po žici.")   