a = input("Unesi string: ")
negativni_jednocifreni = []

def jednocifreni_negativni(a):
    for i in range(len(a)):
        if a[i] == "-" and i < len(a) - 1 and a[i+1].isdigit():
            negativni_jednocifreni.append(int(a[i+1]))

jednocifreni_negativni(a)
print("Negativni jednocifreni:", negativni_jednocifreni)
print(len)