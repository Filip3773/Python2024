a = input("Unesi tekst:")
a = list(a)

if any(x in a for x in ["a","e","i","o","u"]):
    print("Ima samoglasnik")
    
else: 
    print("Nema samoglasnik")    
    
