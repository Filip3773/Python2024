x1, y1 = input("Unesi x,y kordinate prve tačke (x, y format): ").split(',')
x2, y2 = input("Unesi x,y kordinate druge tačke (x, y format): ").split(',')
sirina1, visina1 = input("Unesite sirinu,visinu zavese (sirina, visina format): ").split(',')

x1 = int(x1)
x2 = int(x2)
y1 = int(y1)
y2 = int(y2)
sirina1 = int(sirina1)
visina1 = int(visina1)


sirina = abs(x1 - x2)
visina = abs(y1 - y2)

if sirina == sirina1 and visina == visina1:
    print("Zavesa odgovara datom prozoru")
