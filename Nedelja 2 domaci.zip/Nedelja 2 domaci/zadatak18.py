temp = int(input("Unetit temperaturu :"))
if  0<temp <100:
  print("Agregatno stanje je tecno")
elif temp<=0:
  print("Agregatno stanje je cvrsto")
elif temp>=100:
  print("Agregtno stanje je gasovito")
