start = int(input("Unesi pocetni broj:  "))
end = int(input("Unesi pocetak :   "))
brojevi = []
def kvadrira(a,b):
    for i in range(a,b+1):
        if i%3 == 0 and i%6 != 0:
           brojevi.append(i)
        
kvadrira(start,end)
print(sum(brojevi))