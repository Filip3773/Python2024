artikli = [50, 30, 100, 20, 80]
sortirani_artikli = sorted(artikli)
drugi_najskuplji_proizvod = sortirani_artikli[-2]
print(drugi_najskuplji_proizvod)
