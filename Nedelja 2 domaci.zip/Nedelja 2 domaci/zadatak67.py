lista = [1,2,3,3,4,5,6,6,7,5,4,8,9,10]
a = int(input("Unesi odredjeni broj:  "))
brojevi = []
def ponavljanje_broja(lista,a):
    for i in lista:
        if i == a:
           brojevi.append(i)

ponavljanje_broja(lista,a)
print(len(brojevi))


