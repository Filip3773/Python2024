def skrati_tekst(tekst):
    if len(tekst) > 30:
        skraceni_tekst = tekst[:27] + "..."
        return skraceni_tekst
    else:
        return tekst

originalni_tekst = input("Unesi tekst: ")
skraceni = skrati_tekst(originalni_tekst)
print(skraceni)
