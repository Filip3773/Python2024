def apsolutna_suma_negativnih_parnih(niz):
    suma = 0
    for broj in niz:
        if broj < 0 and broj % 2 == 0:
            suma += abs(broj)
    return suma


niz = [-2, 7, -5, 3, 1, -4]
rezultat = apsolutna_suma_negativnih_parnih(niz)
print("Output:", rezultat)
