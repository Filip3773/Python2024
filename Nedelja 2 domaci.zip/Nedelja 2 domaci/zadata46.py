plate = [700,800,900,400]
def vise_od_prosecne(a):
  a.sort()
  return a[-2]

print(vise_od_prosecne(plate))

