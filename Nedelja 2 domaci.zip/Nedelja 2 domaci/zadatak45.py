plate = [700,800,900,400]
vece_od_prosecne = []
manje_od_prosecne  = []
def vise_od_prosecne(a):
  prosecna_plata = sum(a) // len(a)
  for i in a:
    if i > prosecna_plata:
      vece_od_prosecne.append(i)
    else:
      manje_od_prosecne.append(i)

vise_od_prosecne(plate)
print(len(vece_od_prosecne))
print(manje_od_prosecne)