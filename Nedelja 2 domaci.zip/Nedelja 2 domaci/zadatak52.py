a = input("Unesi tekst: ")
pre = input("Unesi prefiks:  ")
suf = input("Unesi sufiks: ")
num = int(input("Unesi broj ponavljanaj sufiksa i prefiksa :"))


def prosireni_string(a,pre,suf,num):
    print((pre*num)+a+(suf*num))
    
prosireni_string(a,pre,suf,num)
