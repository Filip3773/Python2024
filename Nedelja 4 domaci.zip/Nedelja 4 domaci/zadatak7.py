from functools import reduce

lista = ['apple', 'banana', 'apple', 'orange', 'banana', 'apple']
def frekvencija(lista):
    frekvencija_d = dict(map(lambda x:(x,1),list))
    frekvencija = reduce(lambda x,y : x+y,frekvencija_d.values())
    return frekvencija_d,frekvencija

frekvencija_elementa, ukupna_frekvencija = frekvencija(lista)
print("Frekvencija elementa",frekvencija_elementa)
print("Ukupna frekvencija " ,ukupna_frekvencija)
