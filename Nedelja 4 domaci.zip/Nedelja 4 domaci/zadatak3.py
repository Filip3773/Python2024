def filtriranje_studenata(lista):
    filtriranje = filter(lambda student:student['godine'] > 21 , lista)
    sortiranje = sorted(filtriranje,key = lambda student:student['prosek'])
    return sortiranje


lista = [
    {'ime':'Krsto','godine':25,'prosek':6.7},
    {'ime':'Ivan','godine':24,'prosek':8.9},
    {'ime':'Boris','godine':21,'prosek':9.1},
    {'ime':'Dimitrije','godine':23,'prosek':8.7},
]
outcome = filtriranje_studenata(lista)
print(outcome)