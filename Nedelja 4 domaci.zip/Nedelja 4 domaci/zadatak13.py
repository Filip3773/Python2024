import csv

def append_to_file(list_of_products):
    with open('products.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Naziv", "Opis", "Godina", "Kolicina", "Cijena"])
        for product in list_of_products:
            writer.writerow([product["naziv"], product["opis"], product["godina"], product["kolicina"], product["cijena"]])


def get_products_older_than(year):
    older_products = []
    with open('products.csv', 'r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            if int(row['Godina']) >= year:  
                older_products.append(row)
    return older_products


def max_possible_revenue():
    total_revenue = 0
    with open('products.csv', 'r', newline='') as file:
        reader = csv.DictReader(file)
        for row in reader:
            total_revenue += int(row['kolicina']) * int(row['cijena'])  
    return total_revenue


list_of_products = [{"naziv": "Televizor", "opis": "LG televizor 43inc", "godina": 2019, "kolicina": 10, "cijena": 300},
                    {"naziv": "Televizor", "opis": "Samsung televizor 39inc", "godina": 2017, "kolicina": 5, "cijena": 250}]

append_to_file(list_of_products)

older_products = get_products_older_than(2018)
print(older_products)

revenue = max_possible_revenue()
print(revenue)
