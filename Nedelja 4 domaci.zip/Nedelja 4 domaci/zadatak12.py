def da_li_je_heksadecimalan(a):
     try:
         int(a,16)
         return True
     except ValueError:
          return False
     
b = input("Unesite ime datoteke: ")
suma = 0

with open(b ,'r') as file:
     for line in file:
          reci = line.strip().split()
          for rec in reci :
               if rec.startswith("0x") and da_li_je_heksadecimalan(rec[2:0]):
                 decimalni = int(rec,16)
                 if decimalni % 10 ==3:
                     suma += decimalni
print(suma)
