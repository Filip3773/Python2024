import time

def measure_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        print(f"Function '{func.__name__}' executed in {end_time - start_time:.6f} seconds")
        return result
    return wrapper


@measure_time
def add(a, b):
    return a + b

@measure_time
def square(x):
    return x * x

@measure_time
def concatenate_strings(*args):
    return "".join(args)
@measure_time
def cube(x):
    return x*x*x
@measure_time
def add_to_a_power_of(x,n):
    return x**n


print(add(5, 3))
print(square(6))
print(concatenate_strings("Hello", " ", "world"))
print(cube(4))
print(add_to_a_power_of(2,1000000000))