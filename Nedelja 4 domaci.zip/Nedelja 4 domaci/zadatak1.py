import functools

lista =  ["flower","flow","flight"]

print(functools.reduce(lambda a,b:a if len(a) > len(b) else b,lista))