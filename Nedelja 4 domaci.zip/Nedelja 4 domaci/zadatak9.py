def najveca_populacija(grad):
    max_populacija = 0
    largest_settlement = ""

    with open("gradovi.txt",'r') as file:
        for line in file:
            b = line.strip().split(",")
            if b[0] == grad and int(b[2]) >max_populacija:
                  max_populacija = int(b[2])
                  largest_settlement = b[1]

    return largest_settlement


i = input("Unesi naziv grada: ")
largest_settlement = najveca_populacija(i)


if largest_settlement:
    print(f"Naselje sa najvećim brojem stanovnika u gradu {i} je '{largest_settlement}'")
else:
    print("Nema podataka za taj grad u datoteci.")