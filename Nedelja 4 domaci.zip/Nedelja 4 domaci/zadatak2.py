def iznad(imena,ocene):
    iznad = []
    for ime,ocena in zip(imena,ocene):
        if ocena > 8.5:
            iznad.append((ime,ocena))
    return iznad


imena = ["Ivan","Krsto","Boris","Dimitrije"]
ocene =  [8.3,7.2,9.1,8.7]

result = iznad(imena,ocene)
print(result)