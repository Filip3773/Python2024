from functools import reduce 
  
def prosecna_ocena_po_predmetu(lista_ocena):
 def prosecna_ocena(predmet):
     ocene = filter(lambda x:x[2] == predmet,lista_ocena)
     ocene = list(ocene)
     broj_ocena = len(ocene)
     if broj_ocena ==0:
        return 0
     suma = reduce(lambda x,y : x+y[1],ocene,0)
     return suma / broj_ocena
 

 prosecna_ocena_po_predmetu = map(lambda x:(x[2],prosecna_ocena(x[2])),lista_ocena)
 return list(prosecna_ocena_po_predmetu)


lista = [("Krsto",2,"Matematika"),
         ("Ivan",4,"Matematika"),
         ("Damjan",3,"Fizika"),
         ("Boris",5,"Matematika"),]

result = prosecna_ocena_po_predmetu(lista)
print(result)