def najmanja_populacija(drzava):
     min_populacija = float('inf')
     smallest_settlement = ""

     with open("drzave.txt",'r') as file:
         for line in file:
            b = line.strip().split(",")
            if b[0] == drzava and int(b[2]) < min_populacija:
                  min_populacija = int(b[2])
                  smallest_settlement = b[1]

     return smallest_settlement 


i = input("Unesi naziv drzave: ")
smallest_settlement = najmanja_populacija(i)


if smallest_settlement:
    print(f"Grad sa najmanjim brojem stanovnika u drzavi {i} je '{smallest_settlement}'")
else:
    print("Nema podataka za taj grad u datoteci.")