def najmanja_populacija(drzava):
     min_populacija = 0
     smallest_settlement = ""

     with open("drzave.txt",'r') as file:
         for line in file:
            b = line.strip().split(",")
            if b[0] == drzava :
                  min_populacija += int(b[2])
                  smallest_settlement = b[1]

     return min_populacija


i = input("Unesi naziv drzave: ")
smallest_settlement = najmanja_populacija(i)


if smallest_settlement:
    print(f"Drzva  {i} ima  '{smallest_settlement}' stanovnika")
else:
    print("Nema podataka za tu drzavu  u datoteci.")

#Samo sam iskoristio kod sa 10 i 11 ,nisam menjao imena promenljivih 