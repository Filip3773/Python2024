from functools import reduce
def brojanje_reci_u_stringu(lista_stringova):
    def brojac(string):
        return len(string.split())#Ovde on broji reci u datom stringu
    
    broj_reci = map(brojac,lista_stringova)
    ukupno_reci = reduce(lambda x,y: x+y,broj_reci)
    return ukupno_reci

i = ["Hello, World!", "Python is cool", "Functional programming rocks"]

b = brojanje_reci_u_stringu(i)

print(b)