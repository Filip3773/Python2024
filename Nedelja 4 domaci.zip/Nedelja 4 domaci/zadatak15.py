def validacija_kreditne_kartice(broj_kartice):
    if len(broj_kartice) != 16 or not broj_kartice.isdigit():
        return False
    cifre_kartice = [int(cifra) for cifra in broj_kartice]
    for i in range(len(cifre_kartice)-2,-1,-2):
        cifre_kartice[i] *= 2
        if cifre_kartice[i] >9:
            cifre_kartice[i] = cifre_kartice[i] % 10 + cifre_kartice[i] // 10
    
    total_sum = sum(cifre_kartice)


    return total_sum % 10 == 0
def procesuiranje_kk(input_file,output_file):
    with open(input_file,'r') as f_in,open(output_file,'w') as f_out:
        for line in f_in:
            broj_kartice = line.strip()
            if validacija_kreditne_kartice(broj_kartice):
                f_out.write(f"{broj_kartice},Valid\n")
            else:
                f_out.write(f"{broj_kartice},Invalid\n")

input_file = "kreditne_kartice.txt"
output_file = "validnost_kartica.txt"
procesuiranje_kk(input_file,output_file)