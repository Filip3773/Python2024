def promena(niz):
    promena =map(lambda x, y: y -x,niz[:-1],niz[1:])
    promena = list(promena)
    return promena

niz = [1,4,7,10,13]
promena = promena(niz)
print(promena)