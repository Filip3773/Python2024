with open('rectangles.txt','r')as file:
    lines = file.readlines()
naj_povrsina = 0
for line in lines:
    a,b = map(int,line.strip().split(','))
    if a == b:
        povrsina = a*b
        if povrsina > naj_povrsina:
            naj_povrsina = povrsina

print(naj_povrsina)