def append_to_file(list_of_students):
    with open("students.txt", "a") as file:
        for student in list_of_students:
            file.write(f"{student['ime']},{student['prezime']},{student['godina']},{student['prosjek']}\n")

def get_students_with_greater_grade(year, grade):
    grade_ranges = {
        "A": (9.5, 10),
        "B": (8.5, 9.5),
        "C": (7.5, 8.5),
        "D": (6.5, 7.5),
        "E": (6, 6.5)
    }

    min_grade, max_grade = grade_ranges.get(grade, (0, 0))
    if min_grade == 0 and max_grade == 0:
        return []

    with open("students.txt", "r") as file:
        students = []
        for line in file:
            ime_studenta, prezime_studenta, godina_studenta, ocena_studenta = line.strip().split(",")
            godina_studenta = int(godina_studenta)
            ocena_studenta = float(ocena_studenta)
            if godina_studenta == year and min_grade <= ocena_studenta < max_grade:
                students.append({"ime": ime_studenta, "prezime":prezime_studenta, "godina": godina_studenta, "prosjek":ocena_studenta })
    return students

students_to_append = [
    {"ime": "Filip", "prezime": "Jovanovic", "godina": 2, "prosjek": 8.6},
    {"ime": "Boris", "prezime": "Pejovic", "godina": 3, "prosjek": 7.9},
    {"ime": "Dimitrije", "prezime": "Fusic", "godina": 3, "prosjek": 6.9}
]
append_to_file(students_to_append)

year = 3
grade = "C"
result = get_students_with_greater_grade(year, grade)
print("Studenti izdvojeni sa treće godine čiji je prosjek >= 7.5 ")
print(result)

year = 2
grade = "A"
result = get_students_with_greater_grade(year, grade)
print("\nStudenti sa druge godine ciji je prosek veći ili jednak 9.5 : ")
print(result)
