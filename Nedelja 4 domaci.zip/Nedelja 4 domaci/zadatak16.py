zanrovi = ["Action", "Adventure", "RPG", "Strategy", "Simulation"]
def provjeri_ispravnost_unosa(igra):
    if len(igra) != 5:
        return False
    
    if len(igra[0]) < 2 or len(igra[0]) > 50:
        return False
    
    try:
        ocjena = float(igra[1])
        if ocjena < 1 or ocjena > 10:
            return False
    except ValueError:
        return False
    try:
        godina = int(igra[2])
        if godina < 1950 or godina >= 2024:
            return False
    except ValueError:
        return False
    if len(igra[3]) > 40:
        return False
    
    zanrovi_unos = igra[4].split()
    for zanr in zanrovi_unos:
        if zanr not in zanrovi:
            return False
    return True
def unos_novih_igara():
    with open("igrice.txt", "a") as f:
        while True:
            igra = input("Unesite novu igru (naziv;ocjena;godina;izdavac;zanrovi): ").split(";")
            if provjeri_ispravnost_unosa(igra):
                f.write(";".join(igra) + "\n")
                print("Igra uspješno dodana!")
            else:
                print("Neispravan unos. Molimo vas da ponovo unesete igru.")
            unos = input("Želite li unijeti još igara? (da/ne): ")
            if unos.lower() != "da":
                break
def filtriranje_igara():
    
    with open("igrice.txt", "r") as f:
        igre = [igra.strip().split(";") for igra in f.readlines()]
    for igra in igre:
        print(";".join(igra))
unos_novih_igara()
filtriranje_igara()
